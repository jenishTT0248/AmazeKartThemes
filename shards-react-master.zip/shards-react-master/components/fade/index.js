import Fade from "./Fade";

export default Fade;
