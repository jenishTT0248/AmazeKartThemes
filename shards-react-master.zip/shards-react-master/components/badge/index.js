import Badge from "./Badge";

export default Badge;
