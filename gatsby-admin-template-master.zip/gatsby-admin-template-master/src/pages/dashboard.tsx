import React from 'react';
import SEO from '../components/SEO';

const Home = () => {
  return (
    <div>
      <SEO title="Home" />
    </div>
  );
};
export default Home;
