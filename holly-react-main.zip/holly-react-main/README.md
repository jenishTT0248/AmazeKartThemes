# Holly

A React implementation of [Davide Pacilio's](https://cruip.com/) free landing page template, [Holly](https://lukemcdonald.github.io/holly-react/).

# Getting Started

- Run `npm install`
- Run `npm run dev`
