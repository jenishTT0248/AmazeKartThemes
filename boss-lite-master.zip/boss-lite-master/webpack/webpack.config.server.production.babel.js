import baseConfiguration from './webpack.config.server';
export default baseConfiguration;
