module.exports = {
  name: 'Boss Lite',
  desc: 'Boss Lite - Material Admin Dashboard',
  prefix: 'boss',
  footerText: 'Boss Lite All Rights Reserved 2018',
  logoText: 'Boss Lite',
  needLogin: false
};
