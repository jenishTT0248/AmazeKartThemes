module.exports = [
  {
    key: 'settings',
    name: 'Settings',
    link: '/#'
  },
  {
    key: 'help_support',
    name: 'Help & Support',
    link: '/#'
  },
];
