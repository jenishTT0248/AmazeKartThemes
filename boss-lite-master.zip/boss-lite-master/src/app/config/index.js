import config from './default';
import env from './environment';

export default {
  ...config,
  ...env
};
