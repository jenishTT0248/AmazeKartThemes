import * as types from './actionTypes';

export const initAction = (data) => ({ type: types.INIT, data });
export const clearAction = { type: types.CLEAR };
