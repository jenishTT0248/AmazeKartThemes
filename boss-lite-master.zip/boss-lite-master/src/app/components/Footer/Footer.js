import React from 'react';
import styles from './Footer.scss';

const Footer = () => (
  <div className={styles.Footer}>
    Footer
  </div>
);

export default Footer;
