import dotenv from 'dotenv';

export default dotenv.config();
