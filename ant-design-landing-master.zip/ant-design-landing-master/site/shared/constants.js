export const DEFAULT_USER_NAME = 'antd-landing-user-name';

// leancloud
export const DEFAULT_FILE_NAME = 'Edit';
export const DEFAULT_USER_AV_NAME = 'EditUser';

export const DEFAULT_TEMPLATE_DATA = {
  template: [
    'Nav0_0', 'Banner0_0', 'Content0_0',
    'Content1_0', 'Content3_0', 'Footer0_0',
  ],
  config: {},
  style: [],
  other: {},
  page: {},
};
