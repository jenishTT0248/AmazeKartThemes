/* eslin import/no-webpack-loader-syntax:[0] */
import point from '!raw-loader!./point.less';
import common from '!raw-loader!./common.less';
import custom from '!raw-loader!./custom.less';
import content from '!raw-loader!./content.less';

export default {
  common,
  custom,
  point,
  content,
};
