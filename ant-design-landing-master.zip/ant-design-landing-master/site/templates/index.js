module.exports = {
  routes: [
    { path: '/', component: './template/index' },
  ],
};
